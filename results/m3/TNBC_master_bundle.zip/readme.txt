Dummy M3 content
